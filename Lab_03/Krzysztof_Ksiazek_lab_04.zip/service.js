const filterArray = (array) => {
    return array.filter((item) => item % 2 !== 0)
}

module.exports = {
    filterArray: filterArray
}
